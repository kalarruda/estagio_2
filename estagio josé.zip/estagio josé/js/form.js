

var botaoAdicionar = document.querySelector("#adicionar-solicitacao");
botaoAdicionar.addEventListener("click", function(event){
	event.preventDefault(); // previne que ao clicar no botão o evento natural seja efetuado (atualizar a página e apagar o que foi escrito)
	
	var form = document.querySelector("#form-adiciona");
	var informacao = obterInformacaoFormulario(form); // objeto criado lá embaixo

	var formularioTr = montaTr(informacao);

	if(!validaPaciente(informacao)){ // esse if faz com que se o paciente for invalido ele nem entre na var tabela abaixo.
		console.log("valor Invalido");
		return;
	}

	var tabela = document.querySelector("#tabela-informacao");

	tabela.appendChild(formularioTr);

	form.reset();

} );

function obterInformacaoFormulario(form){ 

	var informacao = { // <-- criando um objeto que tem os itens dentro
		nome:form.nome.value, // caracteristicas do objeto "paciente" que valor de "form.nome.value" (separado por VÍRGULAS)
		peso:form.peso.value,
		altura:form.altura.value,
		gordura:form.altura.value,
		imc:calculaImc(form.peso.value, form.altura.value),

	}

	return paciente; 
}

    //var nome = form.nome.value; // pega o "name" para poder pegar o valor escrito
	//var peso = form.peso.value;
	//var altura = form.altura.value;
	//var gordura = form.gordura.value;

function montaTr(paciente){

	var pacienteTr = document.createElement("tr");

	pacienteTr.appendChild(montaTd(paciente.nome,"info-nome"));  // "appendChild" coloca o td dentro do Tr
	pacienteTr.appendChild(montaTd(paciente.peso,"info-peso"));
	pacienteTr.appendChild(montaTd(paciente.altura,"info-altura"));
	pacienteTr.appendChild(montaTd(paciente.gordura,"info-gordura"));
	pacienteTr.appendChild(montaTd(paciente.imc,"info-imc"));

	return pacienteTr;

}

function montaTd(dado,classe){
	var td = document.createElement("td");
	td.textContent = dado;
	td.classList.add(classe);

	return td;
}

	function validaPaciente(paciente){
		if (validaPeso(paciente.peso)){
			return true;
		}else{
			return false;
		}
	}


	/* PARA CRIAR PACIENTE DE FORMA MAIS SIMPLES MAS COM MAIS LINHAS
	var pacienteTr = document.createElement("tr");// cria uma "tr" para poder colocar as variáveis dentro
	pacienteTr.classList.add("paciente"); 
	var nomeTd = document.createElement("td"); // cria uma "td" para colocar dentro da "tr"
	nomeTd.classList.add("info-nome");
	var pesoTd = document.createElement("td");
	nomeTd.classList.add("info-nome");
	var alturaTd = document.createElement("td");
	var gorduraTd = document.createElement("td");
	var imcTd = document.createElement("td");
	
		

	*/