
/*console.log("olá porra");
//alert("fala viado!");

console.log(titulo);
console.log(titulo.textContent);*/

// console.log é para aparecer no console a escrita

var titulo = document.querySelector(".titulo");
titulo.textContent = "Aparecida Nutricionista";

var pacientes = document.querySelectorAll(".paciente"); // seleciona todos com o querySelectorAll
console.log(pacientes);

for (i = 0 ; i < pacientes.length; i++){

	var paciente = pacientes[i];

	var tdPeso = paciente.querySelector(".info-peso");
	var peso = tdPeso.textContent;

	var tdAltura = paciente.querySelector(".info-altura");
	altura = tdAltura.textContent;

	var tdImc = paciente.querySelector(".info-imc")

	var pesoAltura = validaPesoAltura(peso,altura);
	var pesoValido = validaPeso(peso); // true ou false
	var alturaValida =  validaAltura(altura); 
	
	if(!pesoValido){ // se colocar exclamação antes da variável, ela se torna falsa
		
		pesoValido = false;
		tdImc.textContent = "Peso inválido";
		paciente.classList.add("paciente-invalido"); /*Adiciona uma classe dentro do código de HTML ligado a esse item
												NÃO COLOCAR O PONTO "." DA CLASSE ANTES DO NOME!!*/
	}

	if (!alturaValida){
		
		alturaValida=false;
		tdImc.textContent="altura inválida";
		paciente.classList.add("paciente-invalido");
		//paciente.style.backgroundColor="lightcoral"; PODE USAR DESSA FORMA MAS DÁ MAIS TRABALHO NA HORA DE MUDAR
		//paciente.style.color="white";
	}

	if (alturaValida && pesoValido){
		var imc = calculaImc(peso,altura);
		tdImc.textContent = imc; // toFixed seleciona a quantidade de casas decimais, nesse caso escolhi 2 casas
	}

	if (!pesoAltura){
	alturaValida=false;
	pesoValido = false;
	tdImc.textContent="altura e peso inválidos";
	paciente.classList.add("paciente-invalido");
		
	}


}

function validaPeso(peso){

	if (peso >=0 && peso <1000) {
		return true;
	}else{
		return false;
	}
}

function validaAltura(altura){
	if (altura>=0 && altura<=3.0){
		return true;
	}else{
		return false;
	}
}

function validaPesoAltura(peso,altura){
	if(peso >=0 && peso <1000 && altura>=0 && altura<=3.0){
		return true;
	}else{
		return false;
	}
}

function calculaImc(peso,altura){
	var imc = 0;

	imc = peso / (altura*altura);

	return imc.toFixed(2);
}

/* TESTE PARA QUANDO CLICAR NO TÍTULO DE APARECIDA NUTRICIONISTA
titulo.addEventListener("click", function(){
	console.log("Olá fui clicado");
});
-------------------------------------------
function clique (){
	console.log("fui clicado");
}

botaoAdicionar.addEventListener("click",clique);
	VAI APARECER NO CONSOLE "FUI CLICADO"

*/

