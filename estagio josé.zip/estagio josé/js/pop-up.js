/*function iniciaModal (modalID) {
	var  modal = document.getElementById(modalID);
	modal.classList.add('mostrar');


}

var botao = document.querySelector('.btn-adicionar');
botao.addEventListener('click',function(){
	iniciaModal('modal-promocao');
});*/

function abrir (){
	document.getElementById('popup').style.display='block';
}//para abrir o popup

function fechar(){
	document.getElementById('popup').style.display='none';
}//para fechar o popup

function abrirInformacoes(){
	document.getElementById('popupEncontrar').style.display ='block';

}

function fecharInformacoes(){
	document.getElementById('popupEncontrar').style.display='none';
}


