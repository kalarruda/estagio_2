
//INFORMAÇÕES DA PÁGINA PRINCIPAL----------
var aberturaSolicitacao = document.querySelector(".contratos-abertura");
var analiseInicial = document.querySelector(".contratos-analise");
var aceiteResponsavel = document.querySelector(".contratos-aceite");
var relatorioParcial = document.querySelector(".contratos-parcial");
var relatorioFinal = document.querySelector(".contratos-final");
var relatorioConcluido = document.querySelector(".contratos-concluido");
//cria variaveis da primeira linha da página principal

var abertura=0;
var aceite=0;
var analise=0;
var parcial=0;
var final=0;
var concluido=0;
//valores para serem usados nas funções de condições

var btnAdicionar = document.querySelector("#adicionar-solicitacao");
btnAdicionar.addEventListener("click",function(event){
    event.preventDefault();
    //previne que o botao recarregue a página automaticamente 

    adicionaAbertura();   
    //usa função e sempre adiciona abertura de solicitação

    var form = document.querySelector("#form-adiciona");

    var valorform = valorForm(form);
    console.log(valorform);

    //INFORMAÇÕES DO POPUP "ENCONTRAR SOLICITAÇÕES" -------
    var infoId = document.querySelector("#infoId");
    var infoData = document.querySelector("#infoData");
    var infoStatus = document.querySelector("#infoStatus");
    var infoVisualizar = document.querySelector("#infoVisualizar");  

    var informacoesTr = criarTr("infoTr");   

    var visualizarTd = document.createElement("td");
    visualizarTd.textContent = "-";

    informacoesTr.appendChild(criaTd("infoId",valorform.valorId));
    informacoesTr.appendChild(criaTd("infoData",valorform.valorData));
    informacoesTr.appendChild(criaTd("infoStatus",valorform.valorStatus));
    informacoesTr.appendChild(visualizarTd);
    //para colocar todos os valores de tds dentro da "informacoesTr"

    tabelaEncontrar = document.querySelector("#tabela-encontrar");
    tabelaEncontrar.appendChild(informacoesTr);
    //designa essa "informacoestr" dentro da tabela do popup "encontrar solicitações"

    form.reset();
    //apaga os valores assim que apertar o botão
});
  

function adicionaAbertura() {    
    abertura +=1;
    aberturaSolicitacao.textContent = abertura;
    return aberturaSolicitacao;
}//sempre que adicionar uma solicitação vai contar uma "abertura de solicitação"


function valorForm(form){
    var solicitacao = {//cria o objeto "solicitação" 
        valorId: form.id.value,
        valorData: form.data.value,
        valorAnalise: form.analise.value,
        valorStatus: form.status.value,    
        valorAceite: form.aceite.value
        //pegar valor do "form" pelo "name" do popup "cadastrar"
    }

    valores(solicitacao.valorAceite, solicitacao.valorAnalise,solicitacao.valorStatus);
    return solicitacao;
}


function valores(valorAceite, valorAnalise,valorStatus){
    if(valorAceite=="s"){
            aceite +=1;
            aceiteResponsavel.textContent = aceite;            
    }//acrescenta 1 a cada "sim" no "aceite do responsável"

    if(valorAnalise=="s"){
        analise +=1;
        analiseInicial.textContent = analise;            
    }//acrescenta 1 a cada "sim" no "análise Inicial"
    
    if(valorStatus=="parcial"){
        parcial +=1;
        relatorioParcial.textContent = parcial;
    }else if(valorStatus=="final"){
        final +=1;
        relatorioFinal.textContent = final;
    }else if(valorStatus=="concluido"){
        concluido +=1;
        relatorioConcluido.textContent = concluido;
    }//condições para "status relatório" adicionar valores na tabela principal
}


function criarTr(classe){
    var tr = document.createElement("tr");
    //ciar uma linha nova ainda não vinculada a algum lugar
    tr.classList.add(classe);
    //adiciona a classe "inforTr" ao tr criado
    return tr;
}

function criaTd(classe,valor){
    var td = document.createElement("td");//criar uma td nova ainda não vinculada a algum lugar
    td.classList.add(classe);//adiciona a classe à td
    td.textContent = valor;//adiciona o valor escrito/escolhido à td
    return td;
}








